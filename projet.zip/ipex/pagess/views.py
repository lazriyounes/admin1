from django.shortcuts import render,redirect ,get_object_or_404
from .models import *
from .forms import ProductForm ,CatForm ,WilayaForm

# Create your views here.

def index(request):
   
    if request.method =='POST':
        produ =ProductForm(request.POST,request.FILES)
        if produ.is_valid():
             produ.save()
             return redirect('/az/0')

        catsave =CatForm(request.POST )
        if catsave.is_valid():
             catsave.save()
             return redirect('/az/0')
        
        wi =WilayaForm(request.POST,request.FILES)
        if wi.is_valid():
             wi.save()
             return redirect('/az/0')
        
        
    context ={
        'prod':Produit.objects.all(),
         'wila':Wilaya.objects.all(),
        'cat' : Categoryprod.objects.all(),
       'form' : ProductForm(),
       'wilaya':WilayaForm(),
       'categ':CatForm(),
       'allproduit':Produit.objects.filter(active=True).count(),
       'phcl':Produit.objects.filter(etatprod='locale').count(),
       'phcm':Produit.objects.filter(etatprod='importer').count(),

       'plf':Wilaya.objects.filter( prodimporter__isnull=False).count()/9,
       

        'pcul':Produit.objects.filter().count(),
       'pagro':Produit.objects.filter().count(),
        'pcom':Produit.objects.filter().count(),
    }
    return render(request,'pag/index.html',context)


























def second(request):
             search =Produit.objects.all()
             title=None
             if 'search_name' in request.GET:
                title=request.GET['search_name']

             if title:
              search=search.filter(nameprod__icontains = title)



             context ={
                  'prod':search,
                  'cat' : Categoryprod.objects.all(),
            }
   

             return render(request,'pag/prod.html',context)
    

def update(request,id):
   
   pid = Wilaya.objects.get(id=id)
   if request.method =='POST':
        psave =WilayaForm(request.POST,request.FILES,instance=pid)
        if psave.is_valid():
             psave.save()
             return redirect('/az/0')
        
     
   else:
        psave = WilayaForm(instance=pid)         
        context ={
             'form':psave
        }

   

  
   return render(request,'pag/update.html',context)




def update2(request,id):
   
   pidd = Produit.objects.get(id=id)
   if request.method =='POST':
        psaves =ProductForm(request.POST,request.FILES,instance=pidd)
        if psaves.is_valid():
             psaves.save()
             return redirect('/az/0')
        
     
   else:
        psaves = ProductForm(instance=pidd)         
        context ={
             'forms':psaves
        }

   

  
   return render(request,'pag/update.html',context)

def delete(request,id):
       
       



       
       proid = get_object_or_404(Wilaya,id=id)
       if request.method =='POST':
         proid.delete() 
         return redirect('/az/0')
       

       pr = get_object_or_404(Wilaya,id=id)
       if request.method =='POST':
         pr.delete() 
         return redirect('/az/0')
     

       return render(request,'pag/delete.html')