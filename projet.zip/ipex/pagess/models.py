from django.db import models
from multiselectfield import MultiSelectField
from django import forms



# Create your models here.
statproduit ={ 
    ('importer' , 'importer'),
    ('locale' , 'locale'),

}
    


class Categoryprod(models.Model):
    name =models.CharField(max_length=40) 

    def __str__(self):
        return self.name


class Produit (models.Model):
   
    nameprod = models.CharField(max_length=50)
    etatprod = models.CharField(max_length=30 ,choices=statproduit , null=True ,blank=True)
    catprod =models.ForeignKey(Categoryprod ,on_delete=models.CASCADE ,null=True , blank=True)
    active =models.BooleanField(default=True)
  
    def __str__(self):
        return self.nameprod   



class Wilaya (models.Model):
  
    
    nomwilaya =models.CharField(max_length=40)
    prodlocal =MultiSelectField(choices= Produit.objects.all().values_list('nameprod','nameprod'),null=True ,blank=True)
    prodimporter =MultiSelectField(choices= Produit.objects.all().values_list('nameprod','nameprod'),null=True ,blank=True)
    
    def __str__(self):
        return self.nomwilaya




class Checkbox(models.Model):
    coursename = models.CharField(max_length=100)


class Author(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Book(models.Model):
    title = models.CharField(max_length=100)
    authors = models.ManyToManyField(Author)

    def __str__(self):
        return self.title

